App reading CID of internal SD copiing monitor.app from cramfs.

Howto:
Use empty MicroSD, formated FAT32.
Copy the folder applications from the package (including SD_Prepare.app) into the root of this MicroSD.
Insert the prepared MicroSD into the Pocketbook.
Run the app @SD_Prepare, which is now available on the Pocketbook.

The file .sd_original_serial with your CID is created in the root folder of the external SD.
monitor.app is copied into the same folder from cramfs.
